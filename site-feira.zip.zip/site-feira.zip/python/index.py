import qrcode


data = "c:\Users\lucas\Desktop\Qr code feira de ciencias" 

qr = qrcode.QRCode(
    version=1,
    error_correction=qrcode.constants.ERROR_CORRECT_L,
    box_size=10,
    border=4,
)

qr.add_data(data)
qr.make(fit=True)

img = qr.make_image(fill_color="black", back_color="white")

img.save("qr_video.png")

print("QR Code do vídeo gerado com sucesso!")